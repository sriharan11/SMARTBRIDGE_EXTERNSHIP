package com.example.Hospitalmanagmentjava;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HospitalManagmentJavaApplicationTests {

	@Test
	void contextLoads() {
	}

}
