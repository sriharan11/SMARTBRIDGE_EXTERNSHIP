create database employees;
INSERT INTO `employees`.`faculty` (`ID number`, `department`, `Contact number`, `HOD`)
VALUES
  (1, 'Department A', '1234567890', 'John Doe'),
  (2, 'Department B', '9876543210', 'Jane Smith'),
  (3, 'Department C', '5555555555', 'Michael Johnson');
select* from employees.faculty;
UPDATE `employees`.`faculty`
SET department = 'Department A'
WHERE HOD = 'Jane Smith';
SET SQL_SAFE_UPDATES = 0;
alter table employees.faculty add column name varchar(45);
UPDATE `employees`.`faculty`
SET `name` = 'A'
WHERE `ID number` = 1;
UPDATE `employees`.`faculty`
SET `name` = 'B'
WHERE `ID number` = 2;
UPDATE `employees`.`faculty`
SET `name` = 'C'
WHERE `ID number` = 3;
CREATE TABLE `students` (`id` INT NOT NULL,`name` VARCHAR(50) NOT NULL,`age` INT NOT NULL,PRIMARY KEY (`id`));
INSERT INTO `students` (`id`, `name`, `age`)
VALUES
  (1, 'John', 20),
  (2, 'Jane', 22),
  (3, 'Michael', 21),
  (4, 'Emily', 19),
  (5, 'David', 23);
SELECT students.name, students.age, faculty.`ID number` AS HOD
FROM students
INNER JOIN faculty ON students.id = faculty.`ID number`;
SELECT students.name, students.age, faculty.`ID number` AS HOD
FROM students
Left JOIN faculty ON students.id = faculty.`ID number`;

SELECT students.name, students.age, faculty.`ID number` AS HOD
FROM students
Right JOIN faculty ON students.id = faculty.`ID number`;

